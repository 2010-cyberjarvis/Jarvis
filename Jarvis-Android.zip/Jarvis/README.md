# Jarvis (Android)

Voice assistant powered by Claude. Say "Jarvis, open YouTube" and it does it.

## Build
1. Install Android Studio. File > Open > select this Jarvis folder. Let Gradle sync.
2. Plug in your phone (USB debugging on) and press Run. Or Build > Build APK(s) and send the APK to any phone.

## First run
1. Get an API key at console.anthropic.com. Paste it in the app, tap Save. Each person uses their own key.
2. Tap "Start always-on". Allow microphone, contacts, phone.
3. Allow "Display over other apps" (needed so Android lets Jarvis open apps from the background), then tap Start again.
4. Say: "Jarvis, open WhatsApp" / "Jarvis, call Mom" / "Jarvis, set an alarm for 7 am" / "Jarvis, navigate to the airport".

## Tips
- Settings > Battery > Jarvis > Unrestricted, so Android doesn't kill it.
- Speech language follows the phone's language.
- New skill: add a tool in Actions.kt (TOOLS list + the `when` in exec()).
