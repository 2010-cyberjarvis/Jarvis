package com.jarvis.app

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Everything Jarvis can physically do on the phone. Add a tool here + in TOOLS to teach it a new skill. */
class Actions(private val ctx: Context) {

    fun run(name: String, a: JSONObject): String =
        try { exec(name, a) } catch (e: Exception) { "Failed: ${e.message}" }

    private fun go(i: Intent): String {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return "Done"
    }

    private fun granted(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun exec(name: String, a: JSONObject): String = when (name) {
        "open_app" -> openApp(a.getString("app_name"))
        "open_url" -> go(Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url"))))
        "web_search" -> go(Intent(Intent.ACTION_VIEW,
            Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.getString("query")))))
        "play_youtube" -> youtube(a.getString("query"))
        "call" -> call(a.getString("contact"))
        "text" -> text(a.getString("contact"), a.getString("message"))
        "set_alarm" -> go(Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour"))
            .putExtra(AlarmClock.EXTRA_MINUTES, a.getInt("minute"))
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Jarvis"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        "set_timer" -> go(Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("seconds"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        "navigate" -> navigate(a.getString("destination"))
        "flashlight" -> {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.setTorchMode(cm.cameraIdList[0], a.getString("state") == "on")
            "Done"
        }
        "open_settings" -> {
            val act = when (a.getString("page")) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "display" -> Settings.ACTION_DISPLAY_SETTINGS
                "sound" -> Settings.ACTION_SOUND_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            go(Intent(act))
        }
        "battery" -> {
            val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))!!
            val pct = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) * 100 /
                b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            "Battery is at $pct percent"
        }
        "current_time" -> SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.getDefault()).format(Date())
        else -> "Unknown tool $name"
    }

    private fun openApp(query: String): String {
        val q = query.lowercase().trim()
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).map { it to it.loadLabel(pm).toString().lowercase() }
        val hit = apps.firstOrNull { it.second == q }
            ?: apps.firstOrNull { it.second.contains(q) }
            ?: apps.firstOrNull { it.second.length > 2 && q.contains(it.second) }
            ?: return "No installed app matches '$query'"
        val i = pm.getLaunchIntentForPackage(hit.first.activityInfo.packageName)
            ?: return "Can't launch ${hit.second}"
        go(i)
        return "Opened ${hit.second}"
    }

    private fun youtube(q: String): String {
        val u = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))
        return try { go(Intent(Intent.ACTION_VIEW, u).setPackage("com.google.android.youtube")) }
        catch (e: ActivityNotFoundException) { go(Intent(Intent.ACTION_VIEW, u)) }
    }

    private fun navigate(dest: String): String {
        val u = Uri.parse("google.navigation:q=" + Uri.encode(dest))
        return try { go(Intent(Intent.ACTION_VIEW, u).setPackage("com.google.android.apps.maps")) }
        catch (e: ActivityNotFoundException) { go(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(dest)))) }
    }

    private fun findNumber(who: String): String? {
        if (who.count { it.isDigit() } >= 5) return who
        if (!granted(android.Manifest.permission.READ_CONTACTS)) return null
        ctx.contentResolver.query(
            Phone.CONTENT_URI, arrayOf(Phone.NUMBER),
            "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$who%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun call(who: String): String {
        val n = findNumber(who) ?: return "Couldn't find a number for $who"
        val uri = Uri.parse("tel:" + Uri.encode(n))
        return if (granted(android.Manifest.permission.CALL_PHONE)) go(Intent(Intent.ACTION_CALL, uri))
        else go(Intent(Intent.ACTION_DIAL, uri))
    }

    private fun text(who: String, msg: String): String {
        val n = findNumber(who) ?: return "Couldn't find a number for $who"
        go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n))).putExtra("sms_body", msg))
        return "Message drafted; the user must tap send"
    }

    companion object {
        private fun tool(name: String, desc: String, vararg params: Pair<String, String>): JSONObject {
            val props = JSONObject()
            val req = JSONArray()
            for ((k, d) in params) {
                val type = if (k == "hour" || k == "minute" || k == "seconds") "integer" else "string"
                props.put(k, JSONObject().put("type", type).put("description", d))
                if (k != "label") req.put(k)
            }
            return JSONObject().put("name", name).put("description", desc)
                .put("input_schema", JSONObject().put("type", "object").put("properties", props).put("required", req))
        }

        val TOOLS: JSONArray = JSONArray()
            .put(tool("open_app", "Open an installed app by its name (YouTube, WhatsApp, Camera, Spotify...).", "app_name" to "App name as a person would say it"))
            .put(tool("open_url", "Open a web address in the browser or matching app.", "url" to "Full URL starting with https://"))
            .put(tool("web_search", "Search Google.", "query" to "Search text"))
            .put(tool("play_youtube", "Search YouTube and open the results in the YouTube app.", "query" to "What to search for"))
            .put(tool("call", "Phone call a contact or number.", "contact" to "Contact name or phone number"))
            .put(tool("text", "Draft an SMS to a contact or number (user taps send).", "contact" to "Contact name or phone number", "message" to "Message text"))
            .put(tool("set_alarm", "Set an alarm for a clock time, 24-hour.", "hour" to "0-23", "minute" to "0-59", "label" to "Optional label"))
            .put(tool("set_timer", "Start a countdown timer.", "seconds" to "Duration in seconds"))
            .put(tool("navigate", "Start Google Maps navigation.", "destination" to "Place or address"))
            .put(tool("flashlight", "Turn the flashlight on or off.", "state" to "on or off"))
            .put(tool("open_settings", "Open a phone settings page.", "page" to "wifi, bluetooth, display, sound or main"))
            .put(tool("battery", "Get the battery percentage."))
            .put(tool("current_time", "Get the current date and time."))
    }
}
