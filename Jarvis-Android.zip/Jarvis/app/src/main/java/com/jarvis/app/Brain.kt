package com.jarvis.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Talks to Claude. Runs the tool-use loop: Claude picks an action, Actions executes it, Claude confirms. */
class Brain(private val ctx: Context, private val actions: Actions) {

    private val history = JSONArray()
    private val prefs get() = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    private val system = "You are Jarvis, a voice assistant living on the user's Android phone. " +
        "Your replies are spoken aloud, so keep them to one or two short sentences, plain text, no markdown or emoji. " +
        "When the user asks you to do something on the phone, call the matching tool, then confirm briefly. " +
        "If a tool fails, say so honestly. Otherwise answer questions directly."

    fun ask(userText: String): String {
        val key = prefs.getString("api_key", "").orEmpty()
        if (key.isBlank()) return "Please add your API key in the Jarvis app first."
        val model = prefs.getString("model", "claude-sonnet-5-5").orEmpty().ifBlank { "claude-sonnet-5-5" }

        history.put(JSONObject().put("role", "user").put("content", userText))
        trim()
        try {
            repeat(6) {
                val resp = call(key, model)
                val content = resp.getJSONArray("content")
                history.put(JSONObject().put("role", "assistant").put("content", content))
                if (resp.optString("stop_reason") != "tool_use") return textOf(content)

                val results = JSONArray()
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    if (b.getString("type") == "tool_use") {
                        val out = actions.run(b.getString("name"), b.getJSONObject("input"))
                        results.put(JSONObject().put("type", "tool_result")
                            .put("tool_use_id", b.getString("id")).put("content", out))
                    }
                }
                history.put(JSONObject().put("role", "user").put("content", results))
            }
            return "Done."
        } catch (e: Exception) {
            return "Sorry, something went wrong. ${e.message}"
        }
    }

    private fun textOf(content: JSONArray): String {
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val b = content.getJSONObject(i)
            if (b.getString("type") == "text") sb.append(b.getString("text"))
        }
        return sb.toString().ifBlank { "Done." }
    }

    /** Keep recent context; always start on a plain user message so tool pairs never get split. */
    private fun trim() {
        while (history.length() > 20) history.remove(0)
        while (history.length() > 0) {
            val m = history.getJSONObject(0)
            if (m.getString("role") == "user" && m.get("content") is String) break
            history.remove(0)
        }
    }

    private fun call(key: String, model: String): JSONObject {
        val body = JSONObject()
            .put("model", model).put("max_tokens", 1024)
            .put("system", system).put("tools", Actions.TOOLS).put("messages", history)
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.doOutput = true
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (code !in 200..299) throw Exception("API error $code: ${txt.take(160)}")
        return JSONObject(txt)
    }
}
