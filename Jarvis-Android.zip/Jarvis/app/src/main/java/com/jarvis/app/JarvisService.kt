package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.Locale
import java.util.concurrent.Executors

/**
 * The engine. Listens -> (wake word "Jarvis") -> asks Claude -> runs phone actions -> speaks.
 * alwaysOn=true: keeps listening for "Jarvis ...". alwaysOn=false: one command, then stops.
 */
class JarvisService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var brain: Brain
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var rec: SpeechRecognizer? = null

    private var alwaysOn = false
    private var armed = false      // heard just "Jarvis", waiting for the command
    private var busy = false
    private var speaking = false
    private var running = true

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        brain = Brain(this, Actions(this))

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n: Notification = NotificationCompat.Builder(this, "jarvis")
            .setContentTitle("Jarvis is listening")
            .setContentText("Say \"Jarvis\" followed by a command")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open).setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)

        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) { tts.language = Locale.getDefault(); ttsReady = true }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { afterSpeak() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { main.post { afterSpeak() } }
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        alwaysOn = intent?.getBooleanExtra("always", false) ?: false
        running = true
        armed = false
        Bus.log(if (alwaysOn) "Listening. Say \"Jarvis\" then your command." else "Listening...")
        listen()
        return START_NOT_STICKY
    }

    private fun listen() {
        if (!running || busy || speaking) return
        main.post {
            rec?.destroy()
            rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(p: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(p: Bundle?) {}
                    override fun onEvent(t: Int, p: Bundle?) {}
                    override fun onError(e: Int) {
                        if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { Bus.log("Microphone permission missing."); stopSelf(); return }
                        if (alwaysOn) main.postDelayed({ listen() }, 300)
                        else { Bus.log("Didn't catch that."); stopSelf() }
                    }
                    override fun onResults(r: Bundle?) {
                        handle(r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull())
                    }
                })
                startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false))
            }
        }
    }

    private fun handle(raw: String?) {
        if (raw.isNullOrBlank()) { listen(); return }
        var t = raw.trim()
        if (alwaysOn && !armed) {
            val i = t.lowercase().indexOf("jarvis")
            if (i < 0) { listen(); return }          // not for us, ignore
            t = t.substring(i + 6).trim(' ', ',', '.', '!')
            if (t.isEmpty()) { armed = true; say("Yes?"); return }
        }
        busy = true
        Bus.log("You: $t")
        worker.execute {
            val reply = brain.ask(t)
            main.post { busy = false; armed = false; Bus.log("Jarvis: $reply"); say(reply) }
        }
    }

    private fun say(text: String) {
        speaking = true
        rec?.cancel()
        if (!ttsReady) { afterSpeak(); return }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun afterSpeak() {
        speaking = false
        if (alwaysOn) listen() else stopSelf()
    }

    override fun onDestroy() {
        running = false
        rec?.destroy()
        tts.shutdown()
        worker.shutdownNow()
        Bus.log("Jarvis stopped.")
        super.onDestroy()
    }
}
