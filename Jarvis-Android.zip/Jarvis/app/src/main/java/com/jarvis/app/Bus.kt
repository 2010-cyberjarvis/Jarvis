package com.jarvis.app

/** Tiny in-process log shared between the service and the screen. Main thread only. */
object Bus {
    val lines = ArrayList<String>()
    var listener: ((String) -> Unit)? = null
    fun log(s: String) { lines.add(s); listener?.invoke(s) }
}
