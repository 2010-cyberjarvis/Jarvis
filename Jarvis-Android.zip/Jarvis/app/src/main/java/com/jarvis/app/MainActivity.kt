package com.jarvis.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var keyBox: EditText
    private lateinit var modelBox: EditText
    private var wantAlways = false

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        fun button(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        keyBox = EditText(this).apply {
            hint = "Anthropic API key (sk-ant-...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("api_key", ""))
        }
        modelBox = EditText(this).apply {
            hint = "Model"
            setText(prefs.getString("model", "claude-sonnet-5-5"))
        }
        log = TextView(this).apply { textSize = 15f; setPadding(0, pad / 2, 0, 0) }
        scroll = ScrollView(this).apply { addView(log) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            addView(TextView(context).apply { text = "JARVIS"; textSize = 28f; gravity = Gravity.CENTER })
            addView(keyBox)
            addView(modelBox)
            addView(button("Save") {
                prefs.edit().putString("api_key", keyBox.text.toString().trim())
                    .putString("model", modelBox.text.toString().trim()).apply()
                Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show()
            })
            addView(button("Talk (one command)") { start(false) })
            addView(button("Start always-on (say \"Jarvis...\")") { start(true) })
            addView(button("Stop") { stopService(Intent(context, JarvisService::class.java)) })
            addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        log.text = Bus.lines.joinToString("\n\n")
        Bus.listener = { line ->
            log.append(if (log.text.isEmpty()) line else "\n\n$line")
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    override fun onPause() { Bus.listener = null; super.onPause() }

    private fun start(always: Boolean) {
        if (keyBox.text.isBlank()) { toast("Paste your API key and tap Save first"); return }
        getSharedPreferences("jarvis", MODE_PRIVATE).edit()
            .putString("api_key", keyBox.text.toString().trim())
            .putString("model", modelBox.text.toString().trim()).apply()
        wantAlways = always
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        val need = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1) else launchService()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launchService()
        else toast("Microphone permission is required")
    }

    private fun launchService() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Turn on \"Display over other apps\" for Jarvis, then come back and tap again")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        ContextCompat.startForegroundService(this,
            Intent(this, JarvisService::class.java).putExtra("always", wantAlways))
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
